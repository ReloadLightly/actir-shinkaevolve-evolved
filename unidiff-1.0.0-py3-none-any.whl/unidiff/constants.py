# -*- coding: utf-8 -*-

# The MIT License (MIT)
# Copyright (c) 2014-2023 Matias Bordese
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
# DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
# OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
# OR OTHER DEALINGS IN THE SOFTWARE.


"""Useful constants and regexes used by the package."""

import re


# the filename may be empty (e.g. difflib.unified_diff output without
# fromfile/tofile emits bare "--- " and "+++ " headers)
RE_SOURCE_FILENAME = re.compile(
    r'^--- (?P<filename>"?[^\t\n]*"?)(?:\t(?P<timestamp>[^\n]+))?')
RE_TARGET_FILENAME = re.compile(
    r'^\+\+\+ (?P<filename>"?[^\t\n]*"?)(?:\t(?P<timestamp>[^\n]+))?')


# check diff git line for git renamed files support
RE_DIFF_GIT_HEADER = re.compile(
    r'^diff --git (?P<source>"?a/[^\t\n]+"?) (?P<target>"?b/[^\t\n]+"?)')
RE_DIFF_GIT_HEADER_URI_LIKE = re.compile(
    r'^diff --git (?P<source>.*://[^\t\n]+) (?P<target>.*://[^\t\n]+)')
RE_DIFF_GIT_HEADER_NO_PREFIX = re.compile(
    r'^diff --git (?P<source>[^\t\n]+) (?P<target>[^\t\n]+)')

# check diff git deleted file marker `deleted file mode 100644`
RE_DIFF_GIT_DELETED_FILE = re.compile(r'^deleted file mode (?P<mode>\d+)$')

# check diff git new file marker `new file mode 100644`
RE_DIFF_GIT_NEW_FILE = re.compile(r'^new file mode (?P<mode>\d+)$')

# check diff git file mode change markers `old mode 100644` / `new mode 100755`
RE_DIFF_GIT_OLD_MODE = re.compile(r'^old mode (?P<mode>\d+)$')
RE_DIFF_GIT_NEW_MODE = re.compile(r'^new mode (?P<mode>\d+)$')

# check diff git index line with a trailing mode `index abc..def 100644`
RE_DIFF_GIT_INDEX = re.compile(
    r'^index [0-9a-f]+\.\.[0-9a-f]+ (?P<mode>\d+)$')


# @@ (source offset, length) (target offset, length) @@ (section header)
RE_HUNK_HEADER = re.compile(
    r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))?\ @@[ ]?(.*)")

#    kept line (context)
# \n empty line (treat like context)
# +  added line
# -  deleted line
# \  No newline case
RE_HUNK_BODY_LINE = re.compile(
    r'^(?P<line_type>[- \+\\])(?P<value>.*)', re.DOTALL)
RE_HUNK_EMPTY_BODY_LINE = re.compile(
    r'^(?P<line_type>[- \+\\]?)(?P<value>[\r\n]{1,2})', re.DOTALL)

RE_NO_NEWLINE_MARKER = re.compile(r'^\\ No newline at end of file')

RE_BINARY_DIFF = re.compile(
    r'^Binary files? '
    r'(?P<source_filename>[^\t]+?)(?:\t(?P<source_timestamp>[\s0-9:\+-]+))?'
    r'(?: and (?P<target_filename>[^\t]+?)(?:\t(?P<target_timestamp>[\s0-9:\+-]+))?)? (differ|has changed)')

# git source/target filename prefixes: the standard "a/" and "b/", plus the
# mnemonic prefixes used when diff.mnemonicPrefix is set (c/ i/ o/ w/) and the
# 1/ 2/ pair used by `git diff --no-index`
RE_PATCH_FILE_PREFIX = re.compile(r'^[abciow12]/')

DEFAULT_ENCODING = 'UTF-8'

DEV_NULL = '/dev/null'

# git file mode for a symbolic link
SYMLINK_FILE_MODE = '120000'

LINE_TYPE_ADDED = '+'
LINE_TYPE_REMOVED = '-'
LINE_TYPE_CONTEXT = ' '
LINE_TYPE_EMPTY = ''
LINE_TYPE_NO_NEWLINE = '\\'
LINE_VALUE_NO_NEWLINE = ' No newline at end of file'
