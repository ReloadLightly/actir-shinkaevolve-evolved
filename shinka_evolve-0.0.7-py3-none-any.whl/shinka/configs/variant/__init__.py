"""Variant config group."""
