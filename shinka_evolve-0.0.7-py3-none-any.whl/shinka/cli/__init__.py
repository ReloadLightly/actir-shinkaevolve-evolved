"""CLI entrypoints for Shinka."""

